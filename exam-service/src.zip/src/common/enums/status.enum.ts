export enum Status {
    NOT_STARTED = 'NOT_STARTED',
    STARTED = 'STARTED',
    SUBMITTED = 'SUBMITTED',
  }  