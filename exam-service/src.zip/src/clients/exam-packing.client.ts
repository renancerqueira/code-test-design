import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class ExamPackingClient {
  constructor(private readonly httpService: HttpService) {}

  async generateExamContent(formId: string): Promise<any> {
    const response = this.httpService.post(
      `${process.env.EXAM_PACKING_SERVICE_URL}/exam-packing-service/answer-sheet-contents/v1/${formId}/generate`,
    );

    // Usando firstValueFrom para converter o Observable em Promise
    const result = await firstValueFrom(response);
    return result.data;
  }
}
